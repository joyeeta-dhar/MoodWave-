# Portfolio Management System - Backend API

A comprehensive FastAPI-based backend for intelligent stock portfolio management with AI-powered recommendations and analytics.

## 🎯 Features

### Core Functionality
- ✅ User authentication with JWT
- ✅ Multiple portfolio management per user
- ✅ Stock holdings tracking with buy/sell transactions
- ✅ Real-time stock data integration (Yahoo Finance)
- ✅ Comprehensive portfolio analytics

### Analytics Engine
- **Performance Metrics:**
  - Total Investment & Current Value
  - Profit/Loss tracking
  - CAGR (Compound Annual Growth Rate)
  - Volatility (Standard Deviation)
  - Sharpe Ratio
  - Maximum Drawdown
  - Diversification Score

- **Visualizations:**
  - Sector allocation pie charts
  - Portfolio growth line charts
  - Stock performance comparisons
  - Correlation heatmaps

### Recommendation Engine (Rule-Based)
- Sector concentration warnings
- Volatility vs risk profile matching
- Poor risk-adjusted return alerts
- Maximum drawdown warnings
- Stock-specific buy/sell/hold recommendations
- Position sizing alerts

### AI/ML Modules (Placeholder)
- Risk prediction models
- Trend forecasting
- Portfolio optimization

### RAG Chatbot (Placeholder)
- Portfolio Q&A
- Financial concept explanations
- Personalized insights

## 📁 Project Structure

```
portfolio-backend/
├── app/
│   ├── core/
│   │   ├── config.py          # Configuration settings
│   │   ├── database.py        # Database connection
│   │   └── security.py        # JWT & authentication
│   ├── models/
│   │   ├── user.py            # User model
│   │   ├── portfolio.py       # Portfolio model
│   │   ├── holding.py         # Stock holding model
│   │   └── transaction.py     # Transaction model
│   ├── schemas/
│   │   ├── user.py            # User Pydantic schemas
│   │   ├── portfolio.py       # Portfolio schemas
│   │   ├── analytics.py       # Analytics schemas
│   │   └── chat.py            # Chat schemas
│   ├── routes/
│   │   ├── auth.py            # Authentication endpoints
│   │   ├── portfolios.py      # Portfolio CRUD endpoints
│   │   ├── analytics.py       # Analytics endpoints
│   │   └── chat.py            # Chat endpoints
│   ├── services/
│   │   ├── stock_data.py      # Stock market data service
│   │   ├── analytics.py       # Portfolio analytics
│   │   └── recommendations.py # Recommendation engine
│   ├── ml/
│   │   └── models.py          # ML models (placeholder)
│   └── rag/
│       └── chatbot.py         # RAG chatbot (placeholder)
├── main.py                    # FastAPI application
├── requirements.txt           # Python dependencies
└── .env.example              # Environment variables template
```

## 🚀 Installation

### Prerequisites
- Python 3.8+
- pip

### Setup

1. **Clone the repository**
```bash
cd portfolio-backend
```

2. **Create virtual environment**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. **Install dependencies**
```bash
pip install -r requirements.txt
```

4. **Configure environment variables**
```bash
cp .env.example .env
# Edit .env with your settings
```

5. **Run the application**
```bash
python main.py
# Or use uvicorn directly:
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at `http://localhost:8000`

## 📚 API Documentation

Once running, access interactive API documentation at:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## 🔑 API Endpoints

### Authentication (`/api/auth`)
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login (get JWT token)
- `GET /api/auth/me` - Get current user info
- `PUT /api/auth/me` - Update user profile

### Portfolios (`/api/portfolios`)
- `POST /api/portfolios/` - Create portfolio
- `GET /api/portfolios/` - List all portfolios
- `GET /api/portfolios/{id}` - Get portfolio details
- `PUT /api/portfolios/{id}` - Update portfolio
- `DELETE /api/portfolios/{id}` - Delete portfolio
- `POST /api/portfolios/{id}/holdings` - Add stock
- `PUT /api/portfolios/{id}/holdings/{holding_id}` - Update holding
- `DELETE /api/portfolios/{id}/holdings/{holding_id}` - Delete holding
- `GET /api/portfolios/{id}/transactions` - Get transaction history
- `POST /api/portfolios/{id}/transactions` - Add transaction

### Analytics (`/api/analytics`)
- `GET /api/analytics/portfolios/{id}/metrics` - Get portfolio metrics
- `GET /api/analytics/portfolios/{id}/sector-allocation` - Sector breakdown
- `GET /api/analytics/portfolios/{id}/stock-performance` - Stock performance
- `GET /api/analytics/portfolios/{id}/growth` - Portfolio growth chart
- `GET /api/analytics/portfolios/{id}/correlation` - Correlation matrix
- `GET /api/analytics/portfolios/{id}/recommendations` - Get recommendations
- `GET /api/analytics/portfolios/{id}/complete` - Complete analytics
- `GET /api/analytics/dashboard` - Dashboard summary

### Chat (`/api/chat`)
- `POST /api/chat/` - Chat with AI assistant
- `GET /api/chat/concepts/{key}` - Get financial concept
- `GET /api/chat/concepts` - Search concepts

## 📊 Example API Usage

### 1. Register & Login
```bash
# Register
curl -X POST "http://localhost:8000/api/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "username": "investor1",
    "password": "securepass123",
    "full_name": "John Doe",
    "risk_profile": "Moderate"
  }'

# Login
curl -X POST "http://localhost:8000/api/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=investor1&password=securepass123"
```

### 2. Create Portfolio & Add Stocks
```bash
# Create portfolio
curl -X POST "http://localhost:8000/api/portfolios/" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "My Growth Portfolio",
    "description": "Technology focused portfolio",
    "is_default": true
  }'

# Add stock
curl -X POST "http://localhost:8000/api/portfolios/1/holdings" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "symbol": "AAPL",
    "quantity": 10,
    "average_buy_price": 150.00
  }'
```

### 3. Get Analytics
```bash
# Get complete analytics
curl -X GET "http://localhost:8000/api/analytics/portfolios/1/complete" \
  -H "Authorization: Bearer YOUR_TOKEN"

# Get recommendations
curl -X GET "http://localhost:8000/api/analytics/portfolios/1/recommendations" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

## 🎨 Frontend Integration

### Example Response Formats

**Portfolio Metrics:**
```json
{
  "total_investment": 10000.00,
  "current_value": 11500.00,
  "profit_loss": 1500.00,
  "profit_loss_percentage": 15.00,
  "cagr": 12.50,
  "volatility": 18.30,
  "sharpe_ratio": 1.45,
  "max_drawdown": 8.20,
  "diversification_score": 75.00
}
```

**Sector Allocation:**
```json
[
  {
    "sector": "Technology",
    "percentage": 45.00,
    "value": 4500.00
  },
  {
    "sector": "Healthcare",
    "percentage": 30.00,
    "value": 3000.00
  }
]
```

**Recommendations:**
```json
{
  "risk_warnings": [
    {
      "type": "diversification",
      "severity": "medium",
      "message": "Technology sector represents 45% of your portfolio"
    }
  ],
  "recommendations": [
    {
      "type": "diversify",
      "symbol": null,
      "message": "Consider diversifying into other sectors",
      "reason": "Over-concentration in Technology sector increases risk"
    }
  ],
  "insights": [
    "Your portfolio is up 15% overall",
    "Good annual growth rate of 12.5%",
    "Moderately diversified portfolio"
  ]
}
```

## 🔐 Authentication

The API uses JWT (JSON Web Tokens) for authentication:

1. Register or login to get a token
2. Include token in Authorization header: `Bearer YOUR_TOKEN`
3. Token expires after 30 minutes (configurable)

## 🌐 CORS Configuration

CORS is configured to allow requests from:
- `http://localhost:3000` (React default)
- `http://localhost:5173` (Vite default)

Update `ALLOWED_ORIGINS` in `.env` to add more origins.

## 🧪 Testing

Create a `tests/` directory and add tests:

```python
# tests/test_auth.py
import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_register():
    response = client.post(
        "/api/auth/register",
        json={
            "email": "test@example.com",
            "username": "testuser",
            "password": "testpass123",
            "risk_profile": "Moderate"
        }
    )
    assert response.status_code == 201
```

Run tests:
```bash
pytest
```

## 📈 Future Enhancements

### ML Models
- [ ] Train risk prediction model
- [ ] Implement LSTM for price forecasting
- [ ] Portfolio optimization using Modern Portfolio Theory
- [ ] Sentiment analysis integration

### RAG System
- [ ] Integrate LangChain with OpenAI/Claude
- [ ] Build financial knowledge vector database
- [ ] Implement conversation memory
- [ ] Add market news retrieval

### Additional Features
- [ ] Real-time WebSocket updates
- [ ] Email notifications for alerts
- [ ] PDF report generation
- [ ] Backtesting capabilities
- [ ] Social/community features

## 🛠️ Environment Variables

```env
# Database
DATABASE_URL=sqlite:///./portfolio.db

# JWT
SECRET_KEY=your-secret-key-change-this
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Stock APIs
ALPHA_VANTAGE_API_KEY=your-key-here

# AI/LLM (Optional)
OPENAI_API_KEY=your-key-here

# CORS
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:5173

# App
DEBUG=True
```

## 📝 License

This project is for educational purposes.

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📧 Support

For issues and questions, please create an issue in the repository.

---

**Built with:** FastAPI, SQLAlchemy, Pandas, NumPy, scikit-learn, yfinance

**Status:** ✅ Production Ready (Core Features) | 🚧 In Progress (ML/RAG Features)
