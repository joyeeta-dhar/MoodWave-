"""
Stock market data service using Yahoo Finance and Alpha Vantage
"""
import yfinance as yf
import requests
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import pandas as pd
from app.core.config import settings


class StockDataService:
    """Service for fetching stock market data"""
    
    def __init__(self):
        self.alpha_vantage_key = settings.ALPHA_VANTAGE_API_KEY
    
    def get_current_price(self, symbol: str) -> Optional[float]:
        """
        Get current stock price using Yahoo Finance
        
        Args:
            symbol: Stock ticker symbol
        
        Returns:
            Current price or None if error
        """
        try:
            stock = yf.Ticker(symbol)
            data = stock.history(period="1d")
            if not data.empty:
                return float(data['Close'].iloc[-1])
            return None
        except Exception as e:
            print(f"Error fetching price for {symbol}: {e}")
            return None
    
    def get_stock_info(self, symbol: str) -> Dict:
        """
        Get detailed stock information
        
        Args:
            symbol: Stock ticker symbol
        
        Returns:
            Dictionary with stock info
        """
        try:
            stock = yf.Ticker(symbol)
            info = stock.info
            return {
                "symbol": symbol,
                "company_name": info.get("longName", symbol),
                "sector": info.get("sector", "Unknown"),
                "industry": info.get("industry", "Unknown"),
                "current_price": info.get("currentPrice", self.get_current_price(symbol)),
                "market_cap": info.get("marketCap", 0),
                "pe_ratio": info.get("trailingPE", 0),
                "dividend_yield": info.get("dividendYield", 0),
            }
        except Exception as e:
            print(f"Error fetching info for {symbol}: {e}")
            return {
                "symbol": symbol,
                "company_name": symbol,
                "sector": "Unknown",
                "current_price": self.get_current_price(symbol)
            }
    
    def get_historical_prices(
        self,
        symbol: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        period: str = "1y"
    ) -> pd.DataFrame:
        """
        Get historical stock prices
        
        Args:
            symbol: Stock ticker symbol
            start_date: Start date for historical data
            end_date: End date for historical data
            period: Period string (1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, 10y, ytd, max)
        
        Returns:
            DataFrame with historical prices
        """
        try:
            stock = yf.Ticker(symbol)
            if start_date and end_date:
                data = stock.history(start=start_date, end=end_date)
            else:
                data = stock.history(period=period)
            return data
        except Exception as e:
            print(f"Error fetching historical data for {symbol}: {e}")
            return pd.DataFrame()
    
    def get_multiple_prices(self, symbols: List[str]) -> Dict[str, float]:
        """
        Get current prices for multiple stocks
        
        Args:
            symbols: List of stock ticker symbols
        
        Returns:
            Dictionary mapping symbols to prices
        """
        prices = {}
        for symbol in symbols:
            price = self.get_current_price(symbol)
            if price:
                prices[symbol] = price
        return prices
    
    def get_market_data_alpha_vantage(self, symbol: str) -> Dict:
        """
        Get market data using Alpha Vantage API (alternative/backup)
        
        Args:
            symbol: Stock ticker symbol
        
        Returns:
            Dictionary with market data
        """
        if not self.alpha_vantage_key:
            return {}
        
        try:
            url = f"https://www.alphavantage.co/query"
            params = {
                "function": "GLOBAL_QUOTE",
                "symbol": symbol,
                "apikey": self.alpha_vantage_key
            }
            response = requests.get(url, params=params)
            data = response.json()
            
            if "Global Quote" in data:
                quote = data["Global Quote"]
                return {
                    "symbol": symbol,
                    "price": float(quote.get("05. price", 0)),
                    "change": float(quote.get("09. change", 0)),
                    "change_percent": quote.get("10. change percent", "0%"),
                    "volume": int(quote.get("06. volume", 0))
                }
            return {}
        except Exception as e:
            print(f"Error fetching Alpha Vantage data for {symbol}: {e}")
            return {}


# Singleton instance
stock_data_service = StockDataService()
