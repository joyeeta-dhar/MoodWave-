"""
Recommendation engine for portfolio suggestions and risk analysis
"""
from typing import List, Dict
from sqlalchemy.orm import Session
from app.models.portfolio import Portfolio
from app.models.user import User, RiskProfile
from app.services.analytics import PortfolioAnalytics


class RecommendationEngine:
    """Rule-based recommendation engine"""
    
    def __init__(self, db: Session, portfolio: Portfolio, user: User):
        self.db = db
        self.portfolio = portfolio
        self.user = user
        self.analytics = PortfolioAnalytics(db, portfolio)
    
    def generate_recommendations(self) -> Dict:
        """
        Generate personalized recommendations and warnings
        
        Returns:
            Dictionary with warnings and recommendations
        """
        warnings = []
        recommendations = []
        
        # Get analytics metrics
        sector_allocation = self.analytics.get_sector_allocation()
        diversification_score = self.analytics.calculate_diversification_score()
        volatility = self.analytics.calculate_volatility()
        sharpe_ratio = self.analytics.calculate_sharpe_ratio()
        max_drawdown = self.analytics.calculate_max_drawdown()
        
        # Rule 1: Sector concentration warning
        if sector_allocation:
            top_sector = sector_allocation[0]
            if top_sector['percentage'] > 50:
                warnings.append({
                    "type": "diversification",
                    "severity": "high",
                    "message": f"{top_sector['sector']} sector represents {top_sector['percentage']}% of your portfolio"
                })
                recommendations.append({
                    "type": "diversify",
                    "symbol": None,
                    "message": "Consider diversifying into other sectors",
                    "reason": f"Over-concentration in {top_sector['sector']} sector increases risk"
                })
            elif top_sector['percentage'] > 35:
                warnings.append({
                    "type": "diversification",
                    "severity": "medium",
                    "message": f"{top_sector['sector']} sector represents {top_sector['percentage']}% of your portfolio"
                })
        
        # Rule 2: Low diversification score
        if diversification_score < 40:
            warnings.append({
                "type": "diversification",
                "severity": "high",
                "message": f"Low diversification score: {diversification_score}/100"
            })
            recommendations.append({
                "type": "diversify",
                "symbol": None,
                "message": "Add more stocks from different sectors",
                "reason": "Current portfolio lacks adequate diversification"
            })
        
        # Rule 3: Volatility vs Risk Profile
        volatility_warnings = self._check_volatility_risk(volatility)
        warnings.extend(volatility_warnings['warnings'])
        recommendations.extend(volatility_warnings['recommendations'])
        
        # Rule 4: Poor Sharpe Ratio
        if sharpe_ratio < 1:
            warnings.append({
                "type": "sharpe",
                "severity": "medium",
                "message": f"Low risk-adjusted returns (Sharpe Ratio: {sharpe_ratio})"
            })
            recommendations.append({
                "type": "review",
                "symbol": None,
                "message": "Review underperforming stocks",
                "reason": "Portfolio returns don't justify the risk taken"
            })
        
        # Rule 5: High Maximum Drawdown
        if max_drawdown > 30:
            warnings.append({
                "type": "drawdown",
                "severity": "high",
                "message": f"High maximum drawdown: {max_drawdown}%"
            })
            recommendations.append({
                "type": "hedge",
                "symbol": None,
                "message": "Consider adding defensive stocks or bonds",
                "reason": "Portfolio is vulnerable to significant losses"
            })
        elif max_drawdown > 20:
            warnings.append({
                "type": "drawdown",
                "severity": "medium",
                "message": f"Moderate maximum drawdown: {max_drawdown}%"
            })
        
        # Rule 6: Stock-specific recommendations
        stock_recommendations = self._analyze_stock_performance()
        recommendations.extend(stock_recommendations)
        
        # Rule 7: Position sizing warnings
        position_warnings = self._check_position_sizing()
        warnings.extend(position_warnings)
        
        return {
            "risk_warnings": warnings,
            "recommendations": recommendations
        }
    
    def _check_volatility_risk(self, volatility: float) -> Dict:
        """Check if volatility matches user's risk profile"""
        warnings = []
        recommendations = []
        
        risk_thresholds = {
            RiskProfile.CONSERVATIVE: {"max": 15, "ideal": 10},
            RiskProfile.MODERATE: {"max": 25, "ideal": 20},
            RiskProfile.AGGRESSIVE: {"max": 40, "ideal": 30}
        }
        
        threshold = risk_thresholds.get(self.user.risk_profile)
        
        if volatility > threshold['max']:
            warnings.append({
                "type": "volatility",
                "severity": "high",
                "message": f"Portfolio volatility ({volatility}%) is too high for {self.user.risk_profile.value} investor"
            })
            recommendations.append({
                "type": "reduce_risk",
                "symbol": None,
                "message": "Consider adding stable, low-volatility stocks",
                "reason": f"Current volatility exceeds comfort level for {self.user.risk_profile.value} profile"
            })
        elif volatility < threshold['ideal'] * 0.5 and self.user.risk_profile == RiskProfile.AGGRESSIVE:
            recommendations.append({
                "type": "increase_returns",
                "symbol": None,
                "message": "Portfolio may be too conservative for your risk profile",
                "reason": "Consider adding growth stocks for higher potential returns"
            })
        
        return {"warnings": warnings, "recommendations": recommendations}
    
    def _analyze_stock_performance(self) -> List[Dict]:
        """Analyze individual stock performance and generate recommendations"""
        recommendations = []
        stock_performance = self.analytics.get_stock_performance()
        
        for stock in stock_performance:
            # Significant losers
            if stock['profit_loss_percentage'] < -20:
                recommendations.append({
                    "type": "sell",
                    "symbol": stock['symbol'],
                    "message": f"Consider reviewing {stock['symbol']}",
                    "reason": f"Down {abs(stock['profit_loss_percentage'])}% from purchase price"
                })
            
            # Significant winners (take profit suggestion)
            elif stock['profit_loss_percentage'] > 50:
                recommendations.append({
                    "type": "take_profit",
                    "symbol": stock['symbol'],
                    "message": f"Consider taking partial profits on {stock['symbol']}",
                    "reason": f"Up {stock['profit_loss_percentage']}% - secure some gains"
                })
        
        return recommendations
    
    def _check_position_sizing(self) -> List[Dict]:
        """Check if any position is too large"""
        warnings = []
        total_value = self.analytics.calculate_total_investment()
        
        for holding in self.portfolio.holdings:
            position_value = holding.quantity * holding.average_buy_price
            position_pct = (position_value / total_value * 100) if total_value > 0 else 0
            
            if position_pct > 25:
                warnings.append({
                    "type": "concentration",
                    "severity": "high",
                    "message": f"{holding.symbol} represents {position_pct:.1f}% of portfolio"
                })
            elif position_pct > 15:
                warnings.append({
                    "type": "concentration",
                    "severity": "medium",
                    "message": f"{holding.symbol} represents {position_pct:.1f}% of portfolio"
                })
        
        return warnings
    
    def get_insights(self) -> List[str]:
        """Generate portfolio insights"""
        insights = []
        
        metrics = self.analytics.calculate_profit_loss()
        cagr = self.analytics.calculate_cagr()
        diversification = self.analytics.calculate_diversification_score()
        
        # Performance insight
        if metrics['profit_loss_percentage'] > 0:
            insights.append(f"Your portfolio is up {metrics['profit_loss_percentage']}% overall")
        else:
            insights.append(f"Your portfolio is down {abs(metrics['profit_loss_percentage'])}% overall")
        
        # CAGR insight
        if cagr > 15:
            insights.append(f"Excellent annual growth rate of {cagr}%")
        elif cagr > 8:
            insights.append(f"Good annual growth rate of {cagr}%")
        elif cagr > 0:
            insights.append(f"Modest annual growth rate of {cagr}%")
        
        # Diversification insight
        if diversification > 70:
            insights.append("Well-diversified portfolio")
        elif diversification > 50:
            insights.append("Moderately diversified portfolio")
        else:
            insights.append("Portfolio needs better diversification")
        
        return insights
