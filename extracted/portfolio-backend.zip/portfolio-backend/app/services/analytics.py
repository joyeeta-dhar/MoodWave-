"""
Portfolio analytics service for calculating metrics and performance
"""
import numpy as np
import pandas as pd
from typing import List, Dict, Tuple
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from app.models.portfolio import Portfolio
from app.models.holding import Holding
from app.models.transaction import Transaction
from app.services.stock_data import stock_data_service


class PortfolioAnalytics:
    """Service for portfolio analytics and metrics calculation"""
    
    def __init__(self, db: Session, portfolio: Portfolio):
        self.db = db
        self.portfolio = portfolio
        self.holdings = portfolio.holdings
    
    def calculate_total_investment(self) -> float:
        """Calculate total investment amount"""
        total = sum(
            holding.quantity * holding.average_buy_price
            for holding in self.holdings
        )
        return round(total, 2)
    
    def calculate_current_value(self) -> Tuple[float, Dict[str, float]]:
        """
        Calculate current portfolio value
        
        Returns:
            Tuple of (total_value, prices_dict)
        """
        symbols = [h.symbol for h in self.holdings]
        current_prices = stock_data_service.get_multiple_prices(symbols)
        
        total_value = 0
        for holding in self.holdings:
            price = current_prices.get(holding.symbol, holding.average_buy_price)
            total_value += holding.quantity * price
        
        return round(total_value, 2), current_prices
    
    def calculate_profit_loss(self) -> Dict[str, float]:
        """Calculate profit/loss metrics"""
        total_investment = self.calculate_total_investment()
        current_value, _ = self.calculate_current_value()
        
        profit_loss = current_value - total_investment
        profit_loss_pct = (profit_loss / total_investment * 100) if total_investment > 0 else 0
        
        return {
            "total_investment": total_investment,
            "current_value": current_value,
            "profit_loss": round(profit_loss, 2),
            "profit_loss_percentage": round(profit_loss_pct, 2)
        }
    
    def calculate_cagr(self) -> float:
        """
        Calculate Compound Annual Growth Rate (CAGR)
        
        Returns:
            CAGR as percentage
        """
        # Get earliest transaction date
        transactions = self.db.query(Transaction).filter(
            Transaction.portfolio_id == self.portfolio.id
        ).order_by(Transaction.transaction_date).all()
        
        if not transactions:
            return 0.0
        
        start_date = transactions[0].transaction_date
        end_date = datetime.utcnow()
        years = (end_date - start_date).days / 365.25
        
        if years < 0.1:  # Less than ~36 days
            return 0.0
        
        total_investment = self.calculate_total_investment()
        current_value, _ = self.calculate_current_value()
        
        if total_investment <= 0:
            return 0.0
        
        cagr = (pow(current_value / total_investment, 1 / years) - 1) * 100
        return round(cagr, 2)
    
    def calculate_volatility(self) -> float:
        """
        Calculate portfolio volatility (standard deviation of returns)
        
        Returns:
            Annualized volatility as percentage
        """
        try:
            # Get historical data for all holdings
            returns_data = []
            
            for holding in self.holdings:
                hist_data = stock_data_service.get_historical_prices(
                    holding.symbol,
                    period="1y"
                )
                if not hist_data.empty:
                    # Calculate daily returns
                    returns = hist_data['Close'].pct_change().dropna()
                    weight = (holding.quantity * holding.average_buy_price) / self.calculate_total_investment()
                    weighted_returns = returns * weight
                    returns_data.append(weighted_returns)
            
            if not returns_data:
                return 0.0
            
            # Combine all weighted returns
            portfolio_returns = pd.concat(returns_data, axis=1).sum(axis=1)
            
            # Calculate annualized volatility
            daily_volatility = portfolio_returns.std()
            annualized_volatility = daily_volatility * np.sqrt(252) * 100  # 252 trading days
            
            return round(annualized_volatility, 2)
        except Exception as e:
            print(f"Error calculating volatility: {e}")
            return 0.0
    
    def calculate_sharpe_ratio(self, risk_free_rate: float = 0.04) -> float:
        """
        Calculate Sharpe Ratio
        
        Args:
            risk_free_rate: Annual risk-free rate (default 4%)
        
        Returns:
            Sharpe ratio
        """
        cagr = self.calculate_cagr() / 100  # Convert to decimal
        volatility = self.calculate_volatility() / 100  # Convert to decimal
        
        if volatility == 0:
            return 0.0
        
        sharpe = (cagr - risk_free_rate) / volatility
        return round(sharpe, 2)
    
    def calculate_max_drawdown(self) -> float:
        """
        Calculate maximum drawdown
        
        Returns:
            Maximum drawdown as percentage
        """
        try:
            # Get portfolio value over time
            portfolio_values = self._get_portfolio_history()
            
            if len(portfolio_values) < 2:
                return 0.0
            
            values = np.array(portfolio_values)
            cumulative_max = np.maximum.accumulate(values)
            drawdown = (values - cumulative_max) / cumulative_max
            max_drawdown = np.min(drawdown) * 100
            
            return round(abs(max_drawdown), 2)
        except Exception as e:
            print(f"Error calculating max drawdown: {e}")
            return 0.0
    
    def calculate_diversification_score(self) -> float:
        """
        Calculate diversification score (0-100)
        Higher score means better diversification
        
        Returns:
            Diversification score
        """
        if not self.holdings:
            return 0.0
        
        # Factor 1: Number of stocks (max 30 points)
        num_stocks = len(self.holdings)
        stock_score = min(num_stocks * 3, 30)
        
        # Factor 2: Sector diversity (max 40 points)
        sectors = {}
        total_value = self.calculate_total_investment()
        
        for holding in self.holdings:
            sector = holding.sector or "Unknown"
            value = holding.quantity * holding.average_buy_price
            sectors[sector] = sectors.get(sector, 0) + value
        
        # Calculate Herfindahl index for sectors
        sector_weights = [v / total_value for v in sectors.values()]
        herfindahl = sum(w ** 2 for w in sector_weights)
        sector_score = (1 - herfindahl) * 40
        
        # Factor 3: Position sizing (max 30 points)
        position_weights = [
            (h.quantity * h.average_buy_price) / total_value
            for h in self.holdings
        ]
        max_position = max(position_weights) if position_weights else 1
        sizing_score = (1 - max_position) * 30
        
        total_score = stock_score + sector_score + sizing_score
        return round(min(total_score, 100), 2)
    
    def get_sector_allocation(self) -> List[Dict]:
        """
        Get sector allocation breakdown
        
        Returns:
            List of sector allocation dictionaries
        """
        sectors = {}
        total_value = self.calculate_total_investment()
        
        for holding in self.holdings:
            sector = holding.sector or "Unknown"
            value = holding.quantity * holding.average_buy_price
            sectors[sector] = sectors.get(sector, 0) + value
        
        allocation = []
        for sector, value in sectors.items():
            percentage = (value / total_value * 100) if total_value > 0 else 0
            allocation.append({
                "sector": sector,
                "value": round(value, 2),
                "percentage": round(percentage, 2)
            })
        
        return sorted(allocation, key=lambda x: x['percentage'], reverse=True)
    
    def get_stock_performance(self) -> List[Dict]:
        """
        Get individual stock performance
        
        Returns:
            List of stock performance dictionaries
        """
        _, current_prices = self.calculate_current_value()
        performance = []
        
        for holding in self.holdings:
            current_price = current_prices.get(holding.symbol, holding.average_buy_price)
            total_investment = holding.quantity * holding.average_buy_price
            current_value = holding.quantity * current_price
            profit_loss = current_value - total_investment
            profit_loss_pct = (profit_loss / total_investment * 100) if total_investment > 0 else 0
            
            performance.append({
                "symbol": holding.symbol,
                "company_name": holding.company_name or holding.symbol,
                "quantity": holding.quantity,
                "buy_price": holding.average_buy_price,
                "current_price": current_price,
                "total_investment": round(total_investment, 2),
                "current_value": round(current_value, 2),
                "profit_loss": round(profit_loss, 2),
                "profit_loss_percentage": round(profit_loss_pct, 2),
                "sector": holding.sector or "Unknown"
            })
        
        return sorted(performance, key=lambda x: x['profit_loss_percentage'], reverse=True)
    
    def get_correlation_matrix(self) -> Dict:
        """
        Calculate correlation matrix between stocks
        
        Returns:
            Dictionary with symbols and correlation matrix
        """
        try:
            symbols = [h.symbol for h in self.holdings]
            if len(symbols) < 2:
                return {"symbols": symbols, "correlation_matrix": []}
            
            # Get historical prices for all stocks
            price_data = {}
            for symbol in symbols:
                hist_data = stock_data_service.get_historical_prices(symbol, period="6mo")
                if not hist_data.empty:
                    price_data[symbol] = hist_data['Close']
            
            if len(price_data) < 2:
                return {"symbols": symbols, "correlation_matrix": []}
            
            # Create DataFrame and calculate correlation
            df = pd.DataFrame(price_data)
            correlation = df.corr()
            
            return {
                "symbols": list(correlation.columns),
                "correlation_matrix": correlation.values.tolist()
            }
        except Exception as e:
            print(f"Error calculating correlation: {e}")
            return {"symbols": [], "correlation_matrix": []}
    
    def _get_portfolio_history(self) -> List[float]:
        """
        Get historical portfolio values
        
        Returns:
            List of portfolio values over time
        """
        # This is a simplified version - in production, you'd store daily snapshots
        try:
            values = []
            for holding in self.holdings:
                hist_data = stock_data_service.get_historical_prices(holding.symbol, period="1y")
                if not hist_data.empty:
                    holding_values = hist_data['Close'] * holding.quantity
                    values.append(holding_values)
            
            if values:
                portfolio_df = pd.concat(values, axis=1).sum(axis=1)
                return portfolio_df.tolist()
            return []
        except Exception as e:
            print(f"Error getting portfolio history: {e}")
            return []


def get_portfolio_analytics(db: Session, portfolio: Portfolio) -> PortfolioAnalytics:
    """Factory function to create PortfolioAnalytics instance"""
    return PortfolioAnalytics(db, portfolio)
