"""
Transaction database model for buy/sell history
"""
from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime, Enum
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from app.core.database import Base


class TransactionType(str, enum.Enum):
    """Transaction types"""
    BUY = "BUY"
    SELL = "SELL"


class Transaction(Base):
    """Transaction model for stock transactions"""
    __tablename__ = "transactions"
    
    id = Column(Integer, primary_key=True, index=True)
    portfolio_id = Column(Integer, ForeignKey("portfolios.id"), nullable=False)
    symbol = Column(String, nullable=False, index=True)
    transaction_type = Column(Enum(TransactionType), nullable=False)
    quantity = Column(Float, nullable=False)
    price = Column(Float, nullable=False)  # Price per share
    total_amount = Column(Float, nullable=False)  # quantity * price
    transaction_date = Column(DateTime, default=datetime.utcnow)
    notes = Column(String, nullable=True)
    
    # Relationships
    portfolio = relationship("Portfolio", back_populates="transactions")
