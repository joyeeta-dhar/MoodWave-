"""
Holding database model for stock holdings
"""
from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from app.core.database import Base


class Holding(Base):
    """Holding model for stocks in portfolio"""
    __tablename__ = "holdings"
    
    id = Column(Integer, primary_key=True, index=True)
    portfolio_id = Column(Integer, ForeignKey("portfolios.id"), nullable=False)
    symbol = Column(String, nullable=False, index=True)  # Stock ticker symbol
    company_name = Column(String, nullable=True)
    quantity = Column(Float, nullable=False)
    average_buy_price = Column(Float, nullable=False)  # Average purchase price
    sector = Column(String, nullable=True)  # Technology, Healthcare, etc.
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    portfolio = relationship("Portfolio", back_populates="holdings")
