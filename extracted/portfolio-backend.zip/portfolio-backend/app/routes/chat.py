"""
Chat routes for AI assistant
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.user import User
from app.models.portfolio import Portfolio
from app.schemas.chat import ChatRequest, ChatResponse
from app.services.analytics import get_portfolio_analytics
from app.rag.chatbot import chat_with_portfolio, knowledge_base

router = APIRouter(prefix="/chat", tags=["Chat"])


@router.post("/", response_model=ChatResponse)
async def chat(
    chat_request: ChatRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Chat with AI assistant about portfolio
    
    Args:
        chat_request: Chat request with message and optional portfolio_id
        current_user: Current authenticated user
        db: Database session
    
    Returns:
        AI assistant response
    """
    portfolio_context = None
    
    # If portfolio_id provided, get portfolio data
    if chat_request.portfolio_id:
        portfolio = db.query(Portfolio).filter(
            Portfolio.id == chat_request.portfolio_id,
            Portfolio.user_id == current_user.id
        ).first()
        
        if portfolio:
            analytics = get_portfolio_analytics(db, portfolio)
            profit_loss = analytics.calculate_profit_loss()
            
            portfolio_context = {
                "portfolio_id": portfolio.id,
                "portfolio_name": portfolio.name,
                "total_investment": profit_loss['total_investment'],
                "current_value": profit_loss['current_value'],
                "profit_loss": profit_loss['profit_loss'],
                "profit_loss_percentage": profit_loss['profit_loss_percentage'],
                "num_holdings": len(portfolio.holdings),
                "cagr": analytics.calculate_cagr(),
                "volatility": analytics.calculate_volatility(),
                "diversification_score": analytics.calculate_diversification_score()
            }
    
    # Get response from chatbot
    response = chat_with_portfolio(
        message=chat_request.message,
        portfolio_data=portfolio_context,
        conversation_history=chat_request.conversation_history
    )
    
    return ChatResponse(
        message=response.get('message', 'I can help you with your portfolio questions.'),
        suggestions=response.get('suggestions', []),
        data=response.get('data')
    )


@router.get("/concepts/{concept_key}")
async def get_financial_concept(
    concept_key: str,
    current_user: User = Depends(get_current_user)
):
    """
    Get information about a financial concept
    
    Args:
        concept_key: Key for the financial concept
        current_user: Current authenticated user
    
    Returns:
        Concept information
    """
    concept = knowledge_base.get_concept(concept_key)
    
    if not concept:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Concept '{concept_key}' not found"
        )
    
    return concept


@router.get("/concepts")
async def search_financial_concepts(
    query: str,
    current_user: User = Depends(get_current_user)
):
    """
    Search for financial concepts
    
    Args:
        query: Search query
        current_user: Current authenticated user
    
    Returns:
        List of matching concepts
    """
    concepts = knowledge_base.search_concepts(query)
    return {"results": concepts}
