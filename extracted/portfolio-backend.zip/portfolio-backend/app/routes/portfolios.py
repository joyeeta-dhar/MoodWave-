"""
Portfolio management routes
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.user import User
from app.models.portfolio import Portfolio
from app.models.holding import Holding
from app.models.transaction import Transaction, TransactionType
from app.schemas.portfolio import (
    PortfolioCreate,
    PortfolioUpdate,
    PortfolioResponse,
    PortfolioDetailResponse,
    HoldingCreate,
    HoldingUpdate,
    HoldingResponse,
    TransactionCreate,
    TransactionResponse
)
from app.services.stock_data import stock_data_service

router = APIRouter(prefix="/portfolios", tags=["Portfolios"])


# Portfolio CRUD Operations
@router.post("/", response_model=PortfolioResponse, status_code=status.HTTP_201_CREATED)
async def create_portfolio(
    portfolio_data: PortfolioCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Create a new portfolio"""
    # If this is set as default, unset other defaults
    if portfolio_data.is_default:
        db.query(Portfolio).filter(
            Portfolio.user_id == current_user.id,
            Portfolio.is_default == True
        ).update({"is_default": False})
    
    new_portfolio = Portfolio(
        user_id=current_user.id,
        name=portfolio_data.name,
        description=portfolio_data.description,
        is_default=portfolio_data.is_default
    )
    
    db.add(new_portfolio)
    db.commit()
    db.refresh(new_portfolio)
    
    return new_portfolio


@router.get("/", response_model=List[PortfolioResponse])
async def get_portfolios(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get all portfolios for current user"""
    portfolios = db.query(Portfolio).filter(
        Portfolio.user_id == current_user.id
    ).all()
    
    return portfolios


@router.get("/{portfolio_id}", response_model=PortfolioDetailResponse)
async def get_portfolio(
    portfolio_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get specific portfolio with holdings"""
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    return portfolio


@router.put("/{portfolio_id}", response_model=PortfolioResponse)
async def update_portfolio(
    portfolio_id: int,
    portfolio_update: PortfolioUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update portfolio"""
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    if portfolio_update.name is not None:
        portfolio.name = portfolio_update.name
    
    if portfolio_update.description is not None:
        portfolio.description = portfolio_update.description
    
    if portfolio_update.is_default is not None:
        if portfolio_update.is_default:
            # Unset other defaults
            db.query(Portfolio).filter(
                Portfolio.user_id == current_user.id,
                Portfolio.id != portfolio_id
            ).update({"is_default": False})
        portfolio.is_default = portfolio_update.is_default
    
    db.commit()
    db.refresh(portfolio)
    
    return portfolio


@router.delete("/{portfolio_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_portfolio(
    portfolio_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete portfolio"""
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    db.delete(portfolio)
    db.commit()
    
    return None


# Holdings Management
@router.post("/{portfolio_id}/holdings", response_model=HoldingResponse, status_code=status.HTTP_201_CREATED)
async def add_holding(
    portfolio_id: int,
    holding_data: HoldingCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Add a stock to portfolio"""
    # Verify portfolio ownership
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    # Get stock info if not provided
    if not holding_data.company_name or not holding_data.sector:
        stock_info = stock_data_service.get_stock_info(holding_data.symbol)
        if not holding_data.company_name:
            holding_data.company_name = stock_info.get("company_name", holding_data.symbol)
        if not holding_data.sector:
            holding_data.sector = stock_info.get("sector", "Unknown")
    
    # Check if holding already exists
    existing_holding = db.query(Holding).filter(
        Holding.portfolio_id == portfolio_id,
        Holding.symbol == holding_data.symbol.upper()
    ).first()
    
    if existing_holding:
        # Update existing holding
        total_cost = (existing_holding.quantity * existing_holding.average_buy_price +
                     holding_data.quantity * holding_data.average_buy_price)
        total_quantity = existing_holding.quantity + holding_data.quantity
        existing_holding.average_buy_price = total_cost / total_quantity
        existing_holding.quantity = total_quantity
        
        db.commit()
        db.refresh(existing_holding)
        
        # Record transaction
        transaction = Transaction(
            portfolio_id=portfolio_id,
            symbol=holding_data.symbol.upper(),
            transaction_type=TransactionType.BUY,
            quantity=holding_data.quantity,
            price=holding_data.average_buy_price,
            total_amount=holding_data.quantity * holding_data.average_buy_price
        )
        db.add(transaction)
        db.commit()
        
        return existing_holding
    
    # Create new holding
    new_holding = Holding(
        portfolio_id=portfolio_id,
        symbol=holding_data.symbol.upper(),
        company_name=holding_data.company_name,
        quantity=holding_data.quantity,
        average_buy_price=holding_data.average_buy_price,
        sector=holding_data.sector
    )
    
    db.add(new_holding)
    db.commit()
    db.refresh(new_holding)
    
    # Record transaction
    transaction = Transaction(
        portfolio_id=portfolio_id,
        symbol=holding_data.symbol.upper(),
        transaction_type=TransactionType.BUY,
        quantity=holding_data.quantity,
        price=holding_data.average_buy_price,
        total_amount=holding_data.quantity * holding_data.average_buy_price
    )
    db.add(transaction)
    db.commit()
    
    return new_holding


@router.put("/{portfolio_id}/holdings/{holding_id}", response_model=HoldingResponse)
async def update_holding(
    portfolio_id: int,
    holding_id: int,
    holding_update: HoldingUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Update a holding"""
    # Verify portfolio ownership
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    holding = db.query(Holding).filter(
        Holding.id == holding_id,
        Holding.portfolio_id == portfolio_id
    ).first()
    
    if not holding:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Holding not found"
        )
    
    if holding_update.quantity is not None:
        holding.quantity = holding_update.quantity
    
    if holding_update.average_buy_price is not None:
        holding.average_buy_price = holding_update.average_buy_price
    
    db.commit()
    db.refresh(holding)
    
    return holding


@router.delete("/{portfolio_id}/holdings/{holding_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_holding(
    portfolio_id: int,
    holding_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Delete a holding (sell all)"""
    # Verify portfolio ownership
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    holding = db.query(Holding).filter(
        Holding.id == holding_id,
        Holding.portfolio_id == portfolio_id
    ).first()
    
    if not holding:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Holding not found"
        )
    
    # Get current price for transaction record
    current_price = stock_data_service.get_current_price(holding.symbol)
    if not current_price:
        current_price = holding.average_buy_price
    
    # Record sell transaction
    transaction = Transaction(
        portfolio_id=portfolio_id,
        symbol=holding.symbol,
        transaction_type=TransactionType.SELL,
        quantity=holding.quantity,
        price=current_price,
        total_amount=holding.quantity * current_price,
        notes="Full position sold"
    )
    db.add(transaction)
    
    # Delete holding
    db.delete(holding)
    db.commit()
    
    return None


# Transaction History
@router.get("/{portfolio_id}/transactions", response_model=List[TransactionResponse])
async def get_transactions(
    portfolio_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Get transaction history for a portfolio"""
    # Verify portfolio ownership
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    transactions = db.query(Transaction).filter(
        Transaction.portfolio_id == portfolio_id
    ).order_by(Transaction.transaction_date.desc()).all()
    
    return transactions


@router.post("/{portfolio_id}/transactions", response_model=TransactionResponse, status_code=status.HTTP_201_CREATED)
async def add_transaction(
    portfolio_id: int,
    transaction_data: TransactionCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Manually add a transaction"""
    # Verify portfolio ownership
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    transaction = Transaction(
        portfolio_id=portfolio_id,
        symbol=transaction_data.symbol.upper(),
        transaction_type=TransactionType(transaction_data.transaction_type),
        quantity=transaction_data.quantity,
        price=transaction_data.price,
        total_amount=transaction_data.quantity * transaction_data.price,
        notes=transaction_data.notes
    )
    
    db.add(transaction)
    db.commit()
    db.refresh(transaction)
    
    return transaction
