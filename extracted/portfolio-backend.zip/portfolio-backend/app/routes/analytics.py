"""
Analytics routes for portfolio metrics and dashboards
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from datetime import datetime, timedelta
from app.core.database import get_db
from app.core.security import get_current_user
from app.models.user import User
from app.models.portfolio import Portfolio
from app.schemas.analytics import (
    PortfolioMetrics,
    AnalyticsResponse,
    DashboardData,
    SectorAllocation,
    StockPerformance,
    PortfolioGrowth,
    RiskWarning,
    Recommendation
)
from app.services.analytics import get_portfolio_analytics
from app.services.recommendations import RecommendationEngine
from app.services.stock_data import stock_data_service
import pandas as pd

router = APIRouter(prefix="/analytics", tags=["Analytics"])


@router.get("/portfolios/{portfolio_id}/metrics", response_model=PortfolioMetrics)
async def get_portfolio_metrics(
    portfolio_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get comprehensive portfolio metrics
    
    Returns:
        Portfolio performance metrics including CAGR, Sharpe ratio, etc.
    """
    # Verify portfolio ownership
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    analytics = get_portfolio_analytics(db, portfolio)
    
    # Calculate all metrics
    profit_loss = analytics.calculate_profit_loss()
    
    metrics = PortfolioMetrics(
        total_investment=profit_loss['total_investment'],
        current_value=profit_loss['current_value'],
        profit_loss=profit_loss['profit_loss'],
        profit_loss_percentage=profit_loss['profit_loss_percentage'],
        cagr=analytics.calculate_cagr(),
        volatility=analytics.calculate_volatility(),
        sharpe_ratio=analytics.calculate_sharpe_ratio(),
        max_drawdown=analytics.calculate_max_drawdown(),
        diversification_score=analytics.calculate_diversification_score()
    )
    
    return metrics


@router.get("/portfolios/{portfolio_id}/sector-allocation", response_model=List[SectorAllocation])
async def get_sector_allocation(
    portfolio_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get sector allocation breakdown
    
    Returns:
        List of sectors with their allocation percentages
    """
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    analytics = get_portfolio_analytics(db, portfolio)
    sector_data = analytics.get_sector_allocation()
    
    return [SectorAllocation(**sector) for sector in sector_data]


@router.get("/portfolios/{portfolio_id}/stock-performance", response_model=List[StockPerformance])
async def get_stock_performance(
    portfolio_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get individual stock performance
    
    Returns:
        List of stocks with their performance metrics
    """
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    analytics = get_portfolio_analytics(db, portfolio)
    performance_data = analytics.get_stock_performance()
    
    return [StockPerformance(**stock) for stock in performance_data]


@router.get("/portfolios/{portfolio_id}/growth", response_model=List[PortfolioGrowth])
async def get_portfolio_growth(
    portfolio_id: int,
    period: str = "1y",
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get portfolio growth over time
    
    Args:
        period: Time period (1m, 3m, 6m, 1y, 2y, 5y)
    
    Returns:
        List of date-value pairs showing portfolio growth
    """
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    # Get historical data for all holdings
    growth_data = []
    
    try:
        # Collect historical data for each holding
        all_data = {}
        for holding in portfolio.holdings:
            hist_data = stock_data_service.get_historical_prices(holding.symbol, period=period)
            if not hist_data.empty:
                all_data[holding.symbol] = {
                    'prices': hist_data['Close'],
                    'quantity': holding.quantity
                }
        
        if all_data:
            # Find common dates
            dates = None
            for symbol, data in all_data.items():
                if dates is None:
                    dates = data['prices'].index
                else:
                    dates = dates.intersection(data['prices'].index)
            
            # Calculate portfolio value for each date
            for date in dates:
                total_value = sum(
                    data['prices'][date] * data['quantity']
                    for data in all_data.values()
                    if date in data['prices'].index
                )
                growth_data.append(
                    PortfolioGrowth(
                        date=date.strftime('%Y-%m-%d'),
                        value=round(total_value, 2)
                    )
                )
    except Exception as e:
        print(f"Error calculating portfolio growth: {e}")
    
    return growth_data


@router.get("/portfolios/{portfolio_id}/correlation")
async def get_correlation_matrix(
    portfolio_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get correlation matrix between stocks
    
    Returns:
        Correlation matrix data
    """
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    analytics = get_portfolio_analytics(db, portfolio)
    correlation_data = analytics.get_correlation_matrix()
    
    return correlation_data


@router.get("/portfolios/{portfolio_id}/recommendations")
async def get_recommendations(
    portfolio_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get personalized recommendations and risk warnings
    
    Returns:
        Risk warnings and investment recommendations
    """
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    recommendation_engine = RecommendationEngine(db, portfolio, current_user)
    recommendations_data = recommendation_engine.generate_recommendations()
    
    return {
        "risk_warnings": [RiskWarning(**w) for w in recommendations_data['risk_warnings']],
        "recommendations": [Recommendation(**r) for r in recommendations_data['recommendations']],
        "insights": recommendation_engine.get_insights()
    }


@router.get("/portfolios/{portfolio_id}/complete", response_model=AnalyticsResponse)
async def get_complete_analytics(
    portfolio_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get complete analytics including all metrics, allocations, and recommendations
    
    Returns:
        Complete analytics response with all data
    """
    portfolio = db.query(Portfolio).filter(
        Portfolio.id == portfolio_id,
        Portfolio.user_id == current_user.id
    ).first()
    
    if not portfolio:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Portfolio not found"
        )
    
    analytics = get_portfolio_analytics(db, portfolio)
    recommendation_engine = RecommendationEngine(db, portfolio, current_user)
    
    # Get all metrics
    profit_loss = analytics.calculate_profit_loss()
    metrics = PortfolioMetrics(
        total_investment=profit_loss['total_investment'],
        current_value=profit_loss['current_value'],
        profit_loss=profit_loss['profit_loss'],
        profit_loss_percentage=profit_loss['profit_loss_percentage'],
        cagr=analytics.calculate_cagr(),
        volatility=analytics.calculate_volatility(),
        sharpe_ratio=analytics.calculate_sharpe_ratio(),
        max_drawdown=analytics.calculate_max_drawdown(),
        diversification_score=analytics.calculate_diversification_score()
    )
    
    # Get allocations and performance
    sector_allocation = [SectorAllocation(**s) for s in analytics.get_sector_allocation()]
    stock_performance = [StockPerformance(**s) for s in analytics.get_stock_performance()]
    
    # Get growth data (simplified - last 6 months)
    growth_data = []
    try:
        all_data = {}
        for holding in portfolio.holdings:
            hist_data = stock_data_service.get_historical_prices(holding.symbol, period="6mo")
            if not hist_data.empty:
                all_data[holding.symbol] = {
                    'prices': hist_data['Close'],
                    'quantity': holding.quantity
                }
        
        if all_data:
            dates = None
            for symbol, data in all_data.items():
                if dates is None:
                    dates = data['prices'].index
                else:
                    dates = dates.intersection(data['prices'].index)
            
            for date in dates:
                total_value = sum(
                    data['prices'][date] * data['quantity']
                    for data in all_data.values()
                    if date in data['prices'].index
                )
                growth_data.append(
                    PortfolioGrowth(
                        date=date.strftime('%Y-%m-%d'),
                        value=round(total_value, 2)
                    )
                )
    except Exception as e:
        print(f"Error in growth calculation: {e}")
    
    # Get recommendations
    recommendations_data = recommendation_engine.generate_recommendations()
    
    return AnalyticsResponse(
        metrics=metrics,
        sector_allocation=sector_allocation,
        stock_performance=stock_performance,
        portfolio_growth=growth_data,
        correlation_data=analytics.get_correlation_matrix(),
        risk_warnings=[RiskWarning(**w) for w in recommendations_data['risk_warnings']],
        recommendations=[Recommendation(**r) for r in recommendations_data['recommendations']]
    )


@router.get("/dashboard", response_model=List[DashboardData])
async def get_dashboard_summary(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get dashboard summary for all user portfolios
    
    Returns:
        Dashboard data for each portfolio
    """
    portfolios = db.query(Portfolio).filter(
        Portfolio.user_id == current_user.id
    ).all()
    
    dashboard_data = []
    
    for portfolio in portfolios:
        analytics = get_portfolio_analytics(db, portfolio)
        profit_loss = analytics.calculate_profit_loss()
        stock_performance = analytics.get_stock_performance()
        sector_allocation = analytics.get_sector_allocation()
        
        # Get top performers and losers
        sorted_stocks = sorted(stock_performance, key=lambda x: x['profit_loss_percentage'], reverse=True)
        top_performers = sorted_stocks[:3]
        top_losers = sorted_stocks[-3:]
        
        # Get recent transactions
        recent_transactions = db.query(Transaction).filter(
            Transaction.portfolio_id == portfolio.id
        ).order_by(Transaction.transaction_date.desc()).limit(5).all()
        
        dashboard_data.append(DashboardData(
            portfolio_id=portfolio.id,
            portfolio_name=portfolio.name,
            total_value=profit_loss['current_value'],
            total_investment=profit_loss['total_investment'],
            profit_loss=profit_loss['profit_loss'],
            profit_loss_percentage=profit_loss['profit_loss_percentage'],
            top_performers=[StockPerformance(**s) for s in top_performers],
            top_losers=[StockPerformance(**s) for s in top_losers],
            sector_allocation=[SectorAllocation(**s) for s in sector_allocation],
            recent_transactions=[
                {
                    "id": t.id,
                    "symbol": t.symbol,
                    "type": t.transaction_type.value,
                    "quantity": t.quantity,
                    "price": t.price,
                    "total_amount": t.total_amount,
                    "date": t.transaction_date.isoformat()
                }
                for t in recent_transactions
            ]
        ))
    
    return dashboard_data
