"""
Portfolio schemas for request/response validation
"""
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class PortfolioBase(BaseModel):
    """Base portfolio schema"""
    name: str
    description: Optional[str] = None
    is_default: bool = False


class PortfolioCreate(PortfolioBase):
    """Schema for portfolio creation"""
    pass


class PortfolioUpdate(BaseModel):
    """Schema for portfolio update"""
    name: Optional[str] = None
    description: Optional[str] = None
    is_default: Optional[bool] = None


class PortfolioResponse(PortfolioBase):
    """Schema for portfolio response"""
    id: int
    user_id: int
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class HoldingBase(BaseModel):
    """Base holding schema"""
    symbol: str
    company_name: Optional[str] = None
    quantity: float
    average_buy_price: float
    sector: Optional[str] = None


class HoldingCreate(HoldingBase):
    """Schema for holding creation"""
    pass


class HoldingUpdate(BaseModel):
    """Schema for holding update"""
    quantity: Optional[float] = None
    average_buy_price: Optional[float] = None


class HoldingResponse(HoldingBase):
    """Schema for holding response"""
    id: int
    portfolio_id: int
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class TransactionBase(BaseModel):
    """Base transaction schema"""
    symbol: str
    transaction_type: str  # BUY or SELL
    quantity: float
    price: float
    notes: Optional[str] = None


class TransactionCreate(TransactionBase):
    """Schema for transaction creation"""
    pass


class TransactionResponse(TransactionBase):
    """Schema for transaction response"""
    id: int
    portfolio_id: int
    total_amount: float
    transaction_date: datetime
    
    class Config:
        from_attributes = True


class PortfolioDetailResponse(PortfolioResponse):
    """Detailed portfolio response with holdings"""
    holdings: List[HoldingResponse] = []
