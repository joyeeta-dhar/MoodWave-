"""
Analytics schemas for portfolio metrics and recommendations
"""
from pydantic import BaseModel
from typing import List, Dict, Optional
from datetime import datetime


class PortfolioMetrics(BaseModel):
    """Portfolio performance metrics"""
    total_investment: float
    current_value: float
    profit_loss: float
    profit_loss_percentage: float
    cagr: float
    volatility: float
    sharpe_ratio: float
    max_drawdown: float
    diversification_score: float


class SectorAllocation(BaseModel):
    """Sector allocation data"""
    sector: str
    percentage: float
    value: float


class StockPerformance(BaseModel):
    """Individual stock performance"""
    symbol: str
    company_name: str
    quantity: float
    buy_price: float
    current_price: float
    total_investment: float
    current_value: float
    profit_loss: float
    profit_loss_percentage: float
    sector: str


class PortfolioGrowth(BaseModel):
    """Portfolio growth over time"""
    date: str
    value: float


class CorrelationData(BaseModel):
    """Correlation matrix data"""
    symbols: List[str]
    correlation_matrix: List[List[float]]


class RiskWarning(BaseModel):
    """Risk warning message"""
    type: str  # diversification, volatility, drawdown, sharpe
    severity: str  # low, medium, high
    message: str


class Recommendation(BaseModel):
    """Investment recommendation"""
    type: str  # buy, sell, hold, diversify
    symbol: Optional[str] = None
    message: str
    reason: str


class AnalyticsResponse(BaseModel):
    """Complete analytics response"""
    metrics: PortfolioMetrics
    sector_allocation: List[SectorAllocation]
    stock_performance: List[StockPerformance]
    portfolio_growth: List[PortfolioGrowth]
    correlation_data: Optional[CorrelationData] = None
    risk_warnings: List[RiskWarning]
    recommendations: List[Recommendation]


class DashboardData(BaseModel):
    """Dashboard summary data"""
    portfolio_id: int
    portfolio_name: str
    total_value: float
    total_investment: float
    profit_loss: float
    profit_loss_percentage: float
    top_performers: List[StockPerformance]
    top_losers: List[StockPerformance]
    sector_allocation: List[SectorAllocation]
    recent_transactions: List[Dict]
