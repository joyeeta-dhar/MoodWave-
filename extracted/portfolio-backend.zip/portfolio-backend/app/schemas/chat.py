"""
Chat schemas for AI assistant
"""
from pydantic import BaseModel
from typing import List, Optional


class ChatMessage(BaseModel):
    """Chat message schema"""
    role: str  # user or assistant
    content: str


class ChatRequest(BaseModel):
    """Chat request schema"""
    message: str
    portfolio_id: Optional[int] = None
    conversation_history: Optional[List[ChatMessage]] = []


class ChatResponse(BaseModel):
    """Chat response schema"""
    message: str
    suggestions: Optional[List[str]] = []
    data: Optional[dict] = None
