# Quick Start Guide

Get your Portfolio Management System backend up and running in 5 minutes!

## Step 1: Install Python Dependencies

```bash
cd portfolio-backend
pip install -r requirements.txt
```

## Step 2: Set Up Environment

Create `.env` file:

```bash
cp .env.example .env
```

Basic `.env` configuration (you can use defaults for development):
```env
DATABASE_URL=sqlite:///./portfolio.db
SECRET_KEY=dev-secret-key-change-in-production
DEBUG=True
```

## Step 3: Run the Server

```bash
python main.py
```

Or with uvicorn:
```bash
uvicorn main:app --reload
```

✅ Server running at: `http://localhost:8000`
📖 API Docs: `http://localhost:8000/docs`

## Step 4: Test the API

### Using the Interactive Docs

1. Open `http://localhost:8000/docs`
2. Click on "POST /api/auth/register"
3. Click "Try it out"
4. Enter test data:
```json
{
  "email": "test@example.com",
  "username": "testuser",
  "password": "test123456",
  "risk_profile": "Moderate"
}
```
5. Click "Execute"

### Using cURL

**1. Register a user:**
```bash
curl -X POST "http://localhost:8000/api/auth/register" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "username": "testuser",
    "password": "test123456",
    "full_name": "Test User",
    "risk_profile": "Moderate"
  }'
```

**2. Login and get token:**
```bash
curl -X POST "http://localhost:8000/api/auth/login" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=testuser&password=test123456"
```

Save the `access_token` from response!

**3. Create a portfolio:**
```bash
curl -X POST "http://localhost:8000/api/portfolios/" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "My First Portfolio",
    "description": "Test portfolio",
    "is_default": true
  }'
```

**4. Add a stock:**
```bash
curl -X POST "http://localhost:8000/api/portfolios/1/holdings" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "symbol": "AAPL",
    "quantity": 10,
    "average_buy_price": 150.00
  }'
```

**5. Get analytics:**
```bash
curl -X GET "http://localhost:8000/api/analytics/portfolios/1/complete" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

## Step 5: Connect Your Frontend

Update your frontend API configuration:

```javascript
// config.js
const API_BASE_URL = 'http://localhost:8000';
const API_ENDPOINTS = {
  auth: {
    register: `${API_BASE_URL}/api/auth/register`,
    login: `${API_BASE_URL}/api/auth/login`,
    me: `${API_BASE_URL}/api/auth/me`,
  },
  portfolios: {
    list: `${API_BASE_URL}/api/portfolios`,
    detail: (id) => `${API_BASE_URL}/api/portfolios/${id}`,
    holdings: (id) => `${API_BASE_URL}/api/portfolios/${id}/holdings`,
  },
  analytics: {
    metrics: (id) => `${API_BASE_URL}/api/analytics/portfolios/${id}/metrics`,
    complete: (id) => `${API_BASE_URL}/api/analytics/portfolios/${id}/complete`,
    dashboard: `${API_BASE_URL}/api/analytics/dashboard`,
  },
  chat: {
    send: `${API_BASE_URL}/api/chat`,
  }
};

export { API_BASE_URL, API_ENDPOINTS };
```

Example fetch with authentication:

```javascript
// API call example
const token = localStorage.getItem('access_token');

const response = await fetch(
  'http://localhost:8000/api/portfolios/',
  {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  }
);

const portfolios = await response.json();
```

## Common Issues

### Issue: "ModuleNotFoundError"
**Solution:** Make sure you installed all dependencies:
```bash
pip install -r requirements.txt
```

### Issue: "Address already in use"
**Solution:** Port 8000 is busy. Use a different port:
```bash
uvicorn main:app --reload --port 8001
```

### Issue: CORS errors from frontend
**Solution:** Add your frontend URL to `.env`:
```env
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:5173
```

### Issue: Stock data not loading
**Solution:** 
1. Check internet connection
2. Yahoo Finance may be rate limiting - wait a few minutes
3. For more reliable data, get Alpha Vantage API key and add to `.env`:
```env
ALPHA_VANTAGE_API_KEY=your-key-here
```

## Next Steps

1. ✅ Explore all API endpoints at `/docs`
2. ✅ Review `EXAMPLE_RESPONSES.md` for response formats
3. ✅ Check `README.md` for complete documentation
4. ✅ Customize risk rules in `app/services/recommendations.py`
5. ✅ Add more financial metrics in `app/services/analytics.py`

## Sample Test Data

Create a complete test portfolio quickly:

```bash
# After login, use these commands with your token

# Create portfolio
curl -X POST "http://localhost:8000/api/portfolios/" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name": "Tech Portfolio", "is_default": true}'

# Add multiple stocks
for stock in '{"symbol":"AAPL","quantity":10,"average_buy_price":150}' \
            '{"symbol":"MSFT","quantity":5,"average_buy_price":300}' \
            '{"symbol":"GOOGL","quantity":3,"average_buy_price":120}' \
            '{"symbol":"NVDA","quantity":8,"average_buy_price":400}'; do
  curl -X POST "http://localhost:8000/api/portfolios/1/holdings" \
    -H "Authorization: Bearer YOUR_TOKEN" \
    -H "Content-Type: application/json" \
    -d "$stock"
done

# Get complete analytics
curl -X GET "http://localhost:8000/api/analytics/portfolios/1/complete" \
  -H "Authorization: Bearer YOUR_TOKEN" | json_pp
```

## Support

- 📖 Full documentation: See `README.md`
- 🔧 API examples: See `EXAMPLE_RESPONSES.md`
- 🐛 Issues: Create an issue in the repository
- 💬 Questions: Check the `/docs` endpoint

Happy coding! 🚀
