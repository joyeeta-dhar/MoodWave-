# Deployment Guide

This guide covers deploying the Portfolio Management System backend to various platforms.

## Table of Contents
1. [Docker Deployment](#docker-deployment)
2. [Heroku Deployment](#heroku-deployment)
3. [AWS Deployment](#aws-deployment)
4. [Railway Deployment](#railway-deployment)
5. [Production Checklist](#production-checklist)

---

## Docker Deployment

### Prerequisites
- Docker installed
- Docker Compose installed

### Steps

1. **Build and run with Docker Compose:**
```bash
docker-compose up -d
```

2. **Check logs:**
```bash
docker-compose logs -f backend
```

3. **Stop the service:**
```bash
docker-compose down
```

### Manual Docker Build

```bash
# Build image
docker build -t portfolio-backend .

# Run container
docker run -d \
  -p 8000:8000 \
  -e SECRET_KEY="your-secret-key" \
  -e ALLOWED_ORIGINS="https://yourfrontend.com" \
  -v $(pwd)/data:/app/data \
  --name portfolio-backend \
  portfolio-backend
```

---

## Heroku Deployment

### Prerequisites
- Heroku account
- Heroku CLI installed

### Steps

1. **Create Procfile:**
```bash
echo "web: uvicorn main:app --host 0.0.0.0 --port \$PORT" > Procfile
```

2. **Create runtime.txt:**
```bash
echo "python-3.11.0" > runtime.txt
```

3. **Initialize Git and deploy:**
```bash
# Login to Heroku
heroku login

# Create app
heroku create your-portfolio-backend

# Set environment variables
heroku config:set SECRET_KEY="your-secret-key"
heroku config:set ALLOWED_ORIGINS="https://yourfrontend.com"

# Deploy
git init
git add .
git commit -m "Initial commit"
git push heroku main

# Open app
heroku open
```

4. **Check logs:**
```bash
heroku logs --tail
```

---

## AWS Deployment (EC2)

### Prerequisites
- AWS account
- SSH key pair

### Steps

1. **Launch EC2 instance:**
   - Choose Ubuntu 22.04 LTS
   - Select t2.micro (free tier)
   - Configure security group (allow ports 22, 80, 8000)

2. **Connect to instance:**
```bash
ssh -i your-key.pem ubuntu@your-instance-ip
```

3. **Install dependencies:**
```bash
sudo apt update
sudo apt install -y python3-pip python3-venv nginx

# Clone your repository
git clone https://github.com/yourusername/portfolio-backend.git
cd portfolio-backend

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install requirements
pip install -r requirements.txt
```

4. **Create systemd service:**
```bash
sudo nano /etc/systemd/system/portfolio-backend.service
```

Add:
```ini
[Unit]
Description=Portfolio Management Backend
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/portfolio-backend
Environment="PATH=/home/ubuntu/portfolio-backend/venv/bin"
ExecStart=/home/ubuntu/portfolio-backend/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000

[Install]
WantedBy=multi-user.target
```

5. **Start service:**
```bash
sudo systemctl daemon-reload
sudo systemctl start portfolio-backend
sudo systemctl enable portfolio-backend
sudo systemctl status portfolio-backend
```

6. **Configure Nginx (optional):**
```bash
sudo nano /etc/nginx/sites-available/portfolio-backend
```

Add:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Enable:
```bash
sudo ln -s /etc/nginx/sites-available/portfolio-backend /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

---

## Railway Deployment

Railway offers easy deployment with automatic HTTPS.

### Steps

1. **Install Railway CLI:**
```bash
npm install -g @railway/cli
```

2. **Login and deploy:**
```bash
railway login
railway init
railway up
```

3. **Set environment variables:**
```bash
railway variables set SECRET_KEY="your-secret-key"
railway variables set ALLOWED_ORIGINS="https://yourfrontend.com"
```

4. **View logs:**
```bash
railway logs
```

---

## Production Checklist

Before deploying to production, ensure:

### Security
- [ ] Change `SECRET_KEY` to a strong random value
- [ ] Set `DEBUG=False`
- [ ] Use HTTPS (SSL certificate)
- [ ] Configure proper CORS origins
- [ ] Use environment variables for sensitive data
- [ ] Enable rate limiting
- [ ] Set up authentication timeout properly

### Database
- [ ] Use PostgreSQL instead of SQLite for production
- [ ] Set up database backups
- [ ] Configure connection pooling
- [ ] Add database migrations (Alembic)

### Monitoring
- [ ] Set up logging (consider ELK stack)
- [ ] Add error tracking (Sentry)
- [ ] Configure health checks
- [ ] Set up uptime monitoring

### Performance
- [ ] Enable caching (Redis)
- [ ] Add CDN for static files
- [ ] Configure Gunicorn workers properly
- [ ] Optimize database queries
- [ ] Add request rate limiting

### Environment Variables for Production

```env
# Production .env
DATABASE_URL=postgresql://user:password@host:5432/portfolio_db
SECRET_KEY=your-super-secret-production-key-min-32-chars
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
DEBUG=False
ALLOWED_ORIGINS=https://yourfrontend.com,https://www.yourfrontend.com

# Stock APIs
ALPHA_VANTAGE_API_KEY=your-production-key

# Optional: AI/LLM
OPENAI_API_KEY=your-openai-key

# Monitoring (optional)
SENTRY_DSN=your-sentry-dsn
```

---

## Using PostgreSQL in Production

### Update requirements.txt:
```txt
psycopg2-binary==2.9.9
```

### Update DATABASE_URL:
```env
DATABASE_URL=postgresql://username:password@host:5432/database_name
```

### Database Migration with Alembic:

1. **Install Alembic:**
```bash
pip install alembic
alembic init alembic
```

2. **Configure alembic.ini:**
```ini
sqlalchemy.url = postgresql://username:password@host:5432/database_name
```

3. **Create migration:**
```bash
alembic revision --autogenerate -m "Initial migration"
alembic upgrade head
```

---

## Nginx Configuration (Production)

```nginx
server {
    listen 80;
    server_name api.yourportfolio.com;

    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name api.yourportfolio.com;

    ssl_certificate /path/to/fullchain.pem;
    ssl_certificate_key /path/to/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

---

## Monitoring Setup

### Using Sentry for Error Tracking:

```python
# Add to main.py
import sentry_sdk
from sentry_sdk.integrations.fastapi import FastApiIntegration

sentry_sdk.init(
    dsn=settings.SENTRY_DSN,
    integrations=[FastApiIntegration()],
    traces_sample_rate=1.0,
)
```

### Health Check Endpoint:

Already included at `/health`

### Logging Configuration:

```python
# Add to main.py
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('app.log'),
        logging.StreamHandler()
    ]
)
```

---

## Troubleshooting

### Common Issues:

**Port already in use:**
```bash
lsof -ti:8000 | xargs kill -9
```

**Database connection issues:**
- Check DATABASE_URL format
- Ensure database server is running
- Verify network connectivity

**CORS errors:**
- Add frontend URL to ALLOWED_ORIGINS
- Check protocol (http vs https)

**Module not found:**
```bash
pip install -r requirements.txt
```

---

## Support

For deployment issues:
- Check logs: `docker-compose logs` or service logs
- Verify environment variables
- Ensure all dependencies are installed
- Check firewall/security group settings

---

Happy deploying! 🚀
