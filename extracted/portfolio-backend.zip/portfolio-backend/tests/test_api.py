"""
Basic test examples for the Portfolio Management API
Run with: pytest
"""
import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)


def test_root_endpoint():
    """Test the root endpoint"""
    response = client.get("/")
    assert response.status_code == 200
    assert "name" in response.json()
    assert "version" in response.json()


def test_health_check():
    """Test health check endpoint"""
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"


class TestAuthentication:
    """Authentication endpoint tests"""
    
    def test_register_user(self):
        """Test user registration"""
        response = client.post(
            "/api/auth/register",
            json={
                "email": f"test_{pytest.test_id}@example.com",
                "username": f"testuser_{pytest.test_id}",
                "password": "testpass123",
                "risk_profile": "Moderate"
            }
        )
        # First registration should succeed
        # Note: Will fail if user already exists from previous test runs
        assert response.status_code in [201, 400]
    
    def test_register_duplicate_username(self):
        """Test registration with duplicate username"""
        # Register first user
        client.post(
            "/api/auth/register",
            json={
                "email": "unique1@example.com",
                "username": "duplicate_test",
                "password": "testpass123",
                "risk_profile": "Moderate"
            }
        )
        
        # Try to register with same username
        response = client.post(
            "/api/auth/register",
            json={
                "email": "unique2@example.com",
                "username": "duplicate_test",
                "password": "testpass123",
                "risk_profile": "Moderate"
            }
        )
        assert response.status_code == 400
    
    def test_login_invalid_credentials(self):
        """Test login with invalid credentials"""
        response = client.post(
            "/api/auth/login",
            data={
                "username": "nonexistent",
                "password": "wrongpass"
            }
        )
        assert response.status_code == 401


class TestPortfolios:
    """Portfolio endpoint tests"""
    
    @pytest.fixture
    def auth_token(self):
        """Create test user and return auth token"""
        # Register
        client.post(
            "/api/auth/register",
            json={
                "email": "portfolio_test@example.com",
                "username": "portfolio_user",
                "password": "testpass123",
                "risk_profile": "Moderate"
            }
        )
        
        # Login
        response = client.post(
            "/api/auth/login",
            data={
                "username": "portfolio_user",
                "password": "testpass123"
            }
        )
        
        if response.status_code == 200:
            return response.json()["access_token"]
        return None
    
    def test_create_portfolio(self, auth_token):
        """Test portfolio creation"""
        if not auth_token:
            pytest.skip("Auth token not available")
        
        response = client.post(
            "/api/portfolios/",
            headers={"Authorization": f"Bearer {auth_token}"},
            json={
                "name": "Test Portfolio",
                "description": "Testing portfolio creation",
                "is_default": True
            }
        )
        assert response.status_code in [201, 200]
        if response.status_code == 201:
            assert "id" in response.json()
            assert response.json()["name"] == "Test Portfolio"
    
    def test_get_portfolios_unauthorized(self):
        """Test getting portfolios without authentication"""
        response = client.get("/api/portfolios/")
        assert response.status_code == 401


class TestAnalytics:
    """Analytics endpoint tests"""
    
    def test_analytics_unauthorized(self):
        """Test analytics access without authentication"""
        response = client.get("/api/analytics/portfolios/1/metrics")
        assert response.status_code == 401
    
    def test_dashboard_unauthorized(self):
        """Test dashboard access without authentication"""
        response = client.get("/api/analytics/dashboard")
        assert response.status_code == 401


# Run configuration
pytest.test_id = 1

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
