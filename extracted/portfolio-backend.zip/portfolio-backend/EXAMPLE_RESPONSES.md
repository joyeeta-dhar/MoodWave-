# Example API Response Formats

This document provides example JSON responses for all major API endpoints to help frontend developers integrate with the backend.

## Authentication

### POST /api/auth/register
**Response (201 Created):**
```json
{
  "id": 1,
  "email": "user@example.com",
  "username": "investor1",
  "full_name": "John Doe",
  "risk_profile": "Moderate",
  "created_at": "2024-01-15T10:30:00",
  "updated_at": "2024-01-15T10:30:00"
}
```

### POST /api/auth/login
**Response (200 OK):**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "user": {
    "id": 1,
    "email": "user@example.com",
    "username": "investor1",
    "full_name": "John Doe",
    "risk_profile": "Moderate",
    "created_at": "2024-01-15T10:30:00",
    "updated_at": "2024-01-15T10:30:00"
  }
}
```

## Portfolios

### GET /api/portfolios/
**Response (200 OK):**
```json
[
  {
    "id": 1,
    "user_id": 1,
    "name": "Growth Portfolio",
    "description": "Technology focused growth stocks",
    "is_default": true,
    "created_at": "2024-01-15T10:30:00",
    "updated_at": "2024-01-15T10:30:00"
  },
  {
    "id": 2,
    "user_id": 1,
    "name": "Dividend Portfolio",
    "description": "Income generating stocks",
    "is_default": false,
    "created_at": "2024-01-16T11:00:00",
    "updated_at": "2024-01-16T11:00:00"
  }
]
```

### GET /api/portfolios/{id}
**Response (200 OK):**
```json
{
  "id": 1,
  "user_id": 1,
  "name": "Growth Portfolio",
  "description": "Technology focused growth stocks",
  "is_default": true,
  "created_at": "2024-01-15T10:30:00",
  "updated_at": "2024-01-15T10:30:00",
  "holdings": [
    {
      "id": 1,
      "portfolio_id": 1,
      "symbol": "AAPL",
      "company_name": "Apple Inc.",
      "quantity": 10,
      "average_buy_price": 150.00,
      "sector": "Technology",
      "created_at": "2024-01-15T10:35:00",
      "updated_at": "2024-01-15T10:35:00"
    },
    {
      "id": 2,
      "portfolio_id": 1,
      "symbol": "MSFT",
      "company_name": "Microsoft Corporation",
      "quantity": 5,
      "average_buy_price": 300.00,
      "sector": "Technology",
      "created_at": "2024-01-15T10:40:00",
      "updated_at": "2024-01-15T10:40:00"
    }
  ]
}
```

### GET /api/portfolios/{id}/transactions
**Response (200 OK):**
```json
[
  {
    "id": 1,
    "portfolio_id": 1,
    "symbol": "AAPL",
    "transaction_type": "BUY",
    "quantity": 10,
    "price": 150.00,
    "total_amount": 1500.00,
    "transaction_date": "2024-01-15T10:35:00",
    "notes": null
  },
  {
    "id": 2,
    "portfolio_id": 1,
    "symbol": "MSFT",
    "transaction_type": "BUY",
    "quantity": 5,
    "price": 300.00,
    "total_amount": 1500.00,
    "transaction_date": "2024-01-15T10:40:00",
    "notes": null
  }
]
```

## Analytics

### GET /api/analytics/portfolios/{id}/metrics
**Response (200 OK):**
```json
{
  "total_investment": 15000.00,
  "current_value": 17250.00,
  "profit_loss": 2250.00,
  "profit_loss_percentage": 15.00,
  "cagr": 12.50,
  "volatility": 18.30,
  "sharpe_ratio": 1.45,
  "max_drawdown": 8.20,
  "diversification_score": 65.00
}
```

### GET /api/analytics/portfolios/{id}/sector-allocation
**Response (200 OK):**
```json
[
  {
    "sector": "Technology",
    "percentage": 85.00,
    "value": 14662.50
  },
  {
    "sector": "Healthcare",
    "percentage": 15.00,
    "value": 2587.50
  }
]
```

### GET /api/analytics/portfolios/{id}/stock-performance
**Response (200 OK):**
```json
[
  {
    "symbol": "AAPL",
    "company_name": "Apple Inc.",
    "quantity": 10,
    "buy_price": 150.00,
    "current_price": 175.00,
    "total_investment": 1500.00,
    "current_value": 1750.00,
    "profit_loss": 250.00,
    "profit_loss_percentage": 16.67,
    "sector": "Technology"
  },
  {
    "symbol": "MSFT",
    "company_name": "Microsoft Corporation",
    "quantity": 5,
    "buy_price": 300.00,
    "current_price": 350.00,
    "total_investment": 1500.00,
    "current_value": 1750.00,
    "profit_loss": 250.00,
    "profit_loss_percentage": 16.67,
    "sector": "Technology"
  }
]
```

### GET /api/analytics/portfolios/{id}/growth
**Response (200 OK):**
```json
[
  {
    "date": "2024-01-01",
    "value": 15000.00
  },
  {
    "date": "2024-01-02",
    "value": 15100.00
  },
  {
    "date": "2024-01-03",
    "value": 15250.00
  },
  {
    "date": "2024-01-04",
    "value": 15180.00
  },
  {
    "date": "2024-01-05",
    "value": 15400.00
  }
]
```

### GET /api/analytics/portfolios/{id}/correlation
**Response (200 OK):**
```json
{
  "symbols": ["AAPL", "MSFT", "GOOGL"],
  "correlation_matrix": [
    [1.00, 0.85, 0.72],
    [0.85, 1.00, 0.78],
    [0.72, 0.78, 1.00]
  ]
}
```

### GET /api/analytics/portfolios/{id}/recommendations
**Response (200 OK):**
```json
{
  "risk_warnings": [
    {
      "type": "diversification",
      "severity": "high",
      "message": "Technology sector represents 85% of your portfolio"
    },
    {
      "type": "volatility",
      "severity": "medium",
      "message": "Portfolio volatility (18.3%) is moderate for Moderate investor"
    }
  ],
  "recommendations": [
    {
      "type": "diversify",
      "symbol": null,
      "message": "Consider diversifying into other sectors",
      "reason": "Over-concentration in Technology sector increases risk"
    },
    {
      "type": "hold",
      "symbol": "AAPL",
      "message": "Continue holding AAPL",
      "reason": "Strong performance with 16.67% gain"
    }
  ],
  "insights": [
    "Your portfolio is up 15% overall",
    "Good annual growth rate of 12.5%",
    "Portfolio needs better diversification"
  ]
}
```

### GET /api/analytics/portfolios/{id}/complete
**Response (200 OK):**
```json
{
  "metrics": {
    "total_investment": 15000.00,
    "current_value": 17250.00,
    "profit_loss": 2250.00,
    "profit_loss_percentage": 15.00,
    "cagr": 12.50,
    "volatility": 18.30,
    "sharpe_ratio": 1.45,
    "max_drawdown": 8.20,
    "diversification_score": 65.00
  },
  "sector_allocation": [
    {
      "sector": "Technology",
      "percentage": 85.00,
      "value": 14662.50
    }
  ],
  "stock_performance": [
    {
      "symbol": "AAPL",
      "company_name": "Apple Inc.",
      "quantity": 10,
      "buy_price": 150.00,
      "current_price": 175.00,
      "total_investment": 1500.00,
      "current_value": 1750.00,
      "profit_loss": 250.00,
      "profit_loss_percentage": 16.67,
      "sector": "Technology"
    }
  ],
  "portfolio_growth": [
    {
      "date": "2024-01-01",
      "value": 15000.00
    }
  ],
  "correlation_data": {
    "symbols": ["AAPL", "MSFT"],
    "correlation_matrix": [
      [1.00, 0.85],
      [0.85, 1.00]
    ]
  },
  "risk_warnings": [
    {
      "type": "diversification",
      "severity": "high",
      "message": "Technology sector represents 85% of your portfolio"
    }
  ],
  "recommendations": [
    {
      "type": "diversify",
      "symbol": null,
      "message": "Consider diversifying into other sectors",
      "reason": "Over-concentration in Technology sector increases risk"
    }
  ]
}
```

### GET /api/analytics/dashboard
**Response (200 OK):**
```json
[
  {
    "portfolio_id": 1,
    "portfolio_name": "Growth Portfolio",
    "total_value": 17250.00,
    "total_investment": 15000.00,
    "profit_loss": 2250.00,
    "profit_loss_percentage": 15.00,
    "top_performers": [
      {
        "symbol": "AAPL",
        "company_name": "Apple Inc.",
        "quantity": 10,
        "buy_price": 150.00,
        "current_price": 175.00,
        "total_investment": 1500.00,
        "current_value": 1750.00,
        "profit_loss": 250.00,
        "profit_loss_percentage": 16.67,
        "sector": "Technology"
      }
    ],
    "top_losers": [],
    "sector_allocation": [
      {
        "sector": "Technology",
        "percentage": 85.00,
        "value": 14662.50
      }
    ],
    "recent_transactions": [
      {
        "id": 1,
        "symbol": "AAPL",
        "type": "BUY",
        "quantity": 10,
        "price": 150.00,
        "total_amount": 1500.00,
        "date": "2024-01-15T10:35:00"
      }
    ]
  }
]
```

## Chat

### POST /api/chat/
**Request:**
```json
{
  "message": "How is my portfolio performing?",
  "portfolio_id": 1,
  "conversation_history": []
}
```

**Response (200 OK):**
```json
{
  "message": "Your portfolio currently has a value of $17,250.00 with a profit/loss of 15.00%. This represents a gain of $2,250.00.",
  "suggestions": [
    "View detailed analytics",
    "Check sector allocation",
    "See recommendations"
  ],
  "data": null
}
```

### GET /api/chat/concepts/sharpe_ratio
**Response (200 OK):**
```json
{
  "name": "Sharpe Ratio",
  "definition": "A measure of risk-adjusted return, showing how much excess return you receive for the extra volatility.",
  "formula": "Sharpe Ratio = (Return - Risk Free Rate) / Standard Deviation",
  "interpretation": "Ratio > 1 is good, > 2 is very good, > 3 is excellent."
}
```

## Error Responses

### 401 Unauthorized
```json
{
  "detail": "Could not validate credentials"
}
```

### 404 Not Found
```json
{
  "detail": "Portfolio not found"
}
```

### 400 Bad Request
```json
{
  "detail": "Username already registered"
}
```

### 422 Validation Error
```json
{
  "detail": [
    {
      "loc": ["body", "email"],
      "msg": "value is not a valid email address",
      "type": "value_error.email"
    }
  ]
}
```
